# Atlas portainer connector

Commit this folder as the root of its own public GitHub repository. In Atlas choose Add GitHub repository and review the exact commit before installing.

This is a standalone connector package; no Atlas source checkout is needed. The worker publishes versioned REST snapshots using its per-instance token. Credentials are stored on the Atlas host, never in Git.

After changing package files, recalculate every SHA-256 in atlas-addin.json and increment version.

## License

Copyright © 2026 42bios. GPL-3.0-only; see LICENSE.txt.
